Armadillo find protected 1.3
If you have other versions armadillo, help to add the signature.
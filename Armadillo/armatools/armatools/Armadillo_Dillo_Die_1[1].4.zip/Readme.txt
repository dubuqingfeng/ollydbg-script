dilloDIE 1.4 - Armadillo 4.xx unpacker
######################################

This Tool can strip Armadillo Protection from protected Exes/Dlls.


supported features:
-------------------

Standard Features
Debugblocker
CopyMemII
Nanomites
Import Elimination
Strategic Code Splicing


Known Issues:
-------------

Applications protected with Armadillo 3.xx or prior will simply start up
when being loaded into dilloDIE. dilloDIE supports 4.xx Versions only.
VB Applications protected with the Import Elimination feature are not
supported either.


Rebuilding:
-----------

Dumps are 100% working, but for aesthetic reasons one might want to remove
Armadillo Sections from Section header and its Data physically. This can
be done quite comfortable with the CFF Explorer or any simmilar PE Editor.

Armadillo Sections are usually called:

.text1
.adata
.data1
.pdata


Nanomites:
----------

Some things about Nanomites: dilloDIE will resolve all Nanomites correctly
for most Applications. There _might_ be apps though, which are somehow
obfuscated in some parts and dilloDIE will fail in properly detecting all
Nanomarkers, which are used to except Fake Nanomites. In this case one
should use the "Emulate" Option, which will cause dilloDIE not to resolve
Nanomites at unpacking time, but to inject a handler which resolves them at
execution time. Dumps using this handler will work on Windows XP and above
only though.

If Nanomites arent processed correcty, try to activate "Unpack in high
priority class". This should fix some windows internal timing issues.


Options:
--------

If a Dump ain't working correctly, you can try to change some Options.

Deactivate the Disassembler for any protection part if not everything gets
fixed properly (e.g. there are not all import references/nanomites/spliced
jumps fixed/resolved due to code obfuscation which will make the disassmbler
fuck things up).
Decrease or set the Max. Size for Spliced Code sections to 0 if a section
gets wrongly detected as spliced (just in case...;) or increase it to make
a bigger Spliced Code section to be detected properly.


"Give a man a fish, he'll eat for a day. Teach a man how to fish, he'll eat
for a lifetime."

Think about it


(c) 2005-2006 mr_magic